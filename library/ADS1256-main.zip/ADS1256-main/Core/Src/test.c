/*
 * test.c
 *
 *  Created on: Dec 8, 2022
 *      Author: anup
 */

#include "test.h"
#include "ads1255.h"
#include "stdio.h"
#include "stm32f1xx_hal.h"
#include "string.h"
//extern I2C_HandleTypeDef hi2c1;
extern SPI_HandleTypeDef hspi2;
extern UART_HandleTypeDef huart1;
#include "i2c-lcd.h"
ADS125X_t adc1;

int _write(int fd, char *data, int len) {
	HAL_UART_Transmit(&huart1, (uint8_t*) data, len, HAL_MAX_DELAY);
	return len;
}

void setup(void) {
//	lcd_init();
	/* USER CODE BEGIN 2 */
	printf("\n");
	printf("ADC config...\n");
	adc1.csPort = GPIOB;
	adc1.csPin = GPIO_PIN_12;
	adc1.drdyPort = GPIOA;
	adc1.drdyPin = GPIO_PIN_12;
	adc1.vref = 2.5f;
	adc1.oscFreq = ADS125X_OSC_FREQ;

	printf("\n");
	printf("ADC config...\n");

//	lcd_clear();
//	lcd_put_cur(0, 0);
//	lcd_send_string("defining ports");
//	HAL_Delay(1000);
//	HAL_GPIO_WritePin( GPIOA, GPIO_PIN_4, 0);
	ADS125X_Init(&adc1, &hspi2, ADS125X_DRATE_2000SPS, ADS125X_PGA1, 0);
//	HAL_GPIO_WritePin( GPIOA, GPIO_PIN_4, 1);
//	HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);
//	lcd_clear();
//	lcd_put_cur(0, 0);
//	lcd_send_string("init done");
//	HAL_Delay(1000);

	printf("...done\n");
	HAL_Delay(1000);
}

void loop() {
	/* USER CODE END WHILE */
//	toggle(100, 20);
//	lcd_clear();
//	lcd_put_cur(0, 0);
//	lcd_send_string("Loop begin");

	float volt[2] = { 0.0f, 0.0f };
	ADS125X_ChannelDiff_Set(&adc1, ADS125X_MUXP_AIN0, ADS125X_MUXN_AINCOM);
//	ADS125X_Channel_Set(&adc1, ADS125X_MUXP_AIN0)
	ADS125X_CMD_Send(&adc1, ADS125X_CMD_SYNC);
	volt[0] = ADS125X_ADC_ReadVolt(&adc1);
	char value[9];
//	if ((volt[0] > -2.5) & (volt[0] < 2.5)) {
	if (volt[0] < -2.5) {
		volt[0] = volt[0] + 5.0;
	}
	if (volt[0]>2.5){
		volt[0] = volt[0]-5.0;
	}
	sprintf(value, "%f", volt[0]);
	printf(value);
	printf("\t");
	printf("%lu", (unsigned long) HAL_GetTick());
	printf("\n");
//	}

//	lcd_clear();
//	lcd_put_cur(0, 0);
//	lcd_send_string(value);
//	lcd_put_cur(0, 0);
//	lcd_send_string("Value");
//	HAL_Delay(10);
}

void toggle(int a, int b) {
	for (int i = 0; i < b; i++) {
		HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);
//		HAL_Delay(a);
	}
}
