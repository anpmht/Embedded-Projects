/*
 * test.h
 *
 *  Created on: Dec 8, 2022
 *      Author: anup
 */

#include "main.h"
void setup(void);
void loop(void);
void toggle();
int _write(int fd, char *data, int len);
