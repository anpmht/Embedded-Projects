/*
 * sd_card.c
 *
 *  Created on: Nov 29, 2022
 *      Author: admin
 */

#include "sd_card.h"
#include "fatfs.h"
#include "string.h"

FATFS fs; 	// These are included for the fatfs to work
FIL fp;		// These are included for the fatfs to work

UINT bw, br;
DWORD ofs;

FRESULT sd_mount(const char *path) {
	return f_mount(&fs, path, 0);
}

FRESULT sd_unmount(const char *path) {
	return f_mount(NULL, path, 1);
}

/*opens existing file*/
FRESULT sd_open(const char *path, BYTE mode) {
	return f_open(&fp, path, mode);
}

FRESULT sd_write(const char *buff) {
	return f_write(&fp, buff, strlen(buff), &bw);
}

FRESULT sd_append(const char *buff) {
	FRESULT result = sd_lseek();
	if (result != FR_OK)
		return result;
	return f_write(&fp, buff, strlen(buff), &bw);
}


FRESULT sd_read(char *buff) {
	int size = sd_fileSize();
	char ch[(size)];
	FRESULT result;
	result = f_read(&fp, ch, size, &br);
	strcpy(buff, ch);
	return result;
}

FRESULT sd_readln(char *buff) {
	char b[2] = "";
	char ch[MAX_LINE_SIZE] = "";
	FRESULT result;
	while (1) {
		result = f_read(&fp, b, 1, &br);
		if (result != FR_OK)
			return result;
		if (b[0] == '\n')
			break;
		b[1] = '\0';
		strcat(ch, b);
	}

//	printf("%s\n",ch);
	strcpy(buff, ch);
	return result;
}

FRESULT sd_eof() {
	if (f_eof(&fp) == 0)
		return 0;
	return 1;
}

FRESULT sd_lseek() {
	return f_lseek(&fp, sd_fileSize());
}

int sd_fileSize() {
	return (int) f_size(&fp);
}

FRESULT sd_close(void) {
	return f_close(&fp);
}
