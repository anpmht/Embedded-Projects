/*
 * basric_function.c
 *
 *  Created on: Nov 29, 2022
 *      Author: admin
 */

#include "basic_function.h"
#include "sd_card.h"
#include "math.h"
#include "stdio.h"

//extern CAN_HandleTypeDef hcan1;

void toogle(GPIO_TypeDef *gpio_set, uint16_t gpio_pin) {
	for (int i = 0; i < 10; i++) {
		HAL_GPIO_TogglePin(gpio_set, gpio_pin);
		HAL_Delay(100);
	}
}



void ActionMsg(const char *title, const char *error_msg) {
	printf("%s :: %s\n", title, error_msg);
}

//CAN_TxHeaderTypeDef Txheader;
//CAN_RxHeaderTypeDef RxHeader;
//void CAN_Initilization() {
//
//	CAN_FilterTypeDef sFilterConfig;
//
//	sFilterConfig.FilterBank = 0;
//	sFilterConfig.FilterMode = CAN_FILTERMODE_IDMASK;
//	sFilterConfig.FilterScale = CAN_FILTERSCALE_32BIT;
//	sFilterConfig.FilterIdHigh = 0x00; // STDID[10:0] and EXID[17:13]
//	sFilterConfig.FilterIdLow = 0x00; // EXID[12:5] and 3 reserved
//	sFilterConfig.FilterMaskIdHigh = 0x00;
//	sFilterConfig.FilterMaskIdLow = 0x00; //0xFFF8;
//	sFilterConfig.FilterFIFOAssignment = CAN_RX_FIFO0;
//	sFilterConfig.FilterActivation = ENABLE;
//	sFilterConfig.SlaveStartFilterBank = 0;
//
//	if (HAL_CAN_ConfigFilter(&hcan1, &sFilterConfig) != HAL_OK) {
//		printf("Can not apply the can filter\n");
//		return;
//	}
//	ActionMsg("CAN Filter Setup", "Success");
//
//	if (HAL_CAN_Start(&hcan1) != HAL_OK) {
//		ActionMsg("CAN Start", "Failed");
//	} else {
//		ActionMsg("CAN Start", "Succeed");
//	}
//
//	if (HAL_CAN_ActivateNotification(&hcan1, CAN_IT_RX_FIFO0_MSG_PENDING)
//			!= HAL_OK) {
//		ActionMsg("CAN Interrupt activation", "Failed");
//	} else {
//		ActionMsg("CAN Interrupt activation", "Succeed");
//	}
//
//}
//
//void CAN_Transmit(uint32_t ID, char *data) {
//	Txheader.DLC = 8;
//	Txheader.ExtId = ID;
//	Txheader.IDE = CAN_ID_EXT;
//	Txheader.RTR = CAN_RTR_DATA;
//	Txheader.TransmitGlobalTime = DISABLE;
//	uint32_t txMailbox;
//
//	if (HAL_CAN_AddTxMessage(&hcan1, &Txheader, (uint8_t*) data, &txMailbox)
//			!= HAL_OK) {
//		ActionMsg("CAN1 Transmit", "failed");
//		return;
//	}
//	ActionMsg("CAN1 Transmit", "Success");
//
//}
//
//void CAN_Receive_Interupt() {
//	char logdata[1024];
//	int n = 0;
//	uint8_t data[8];
//	if (HAL_CAN_GetRxMessage(&hcan1, CAN_RX_FIFO0, &RxHeader, data) != HAL_OK) {
//		ActionMsg("CAN get msg", "failed");
//		return;
//	}
//	if (RxHeader.IDE == CAN_ID_STD) // Standard CAN DATA SAVE
//	{
//		// append all data to logdata
//		n += sprintf(logdata + n, "%13d ", (int) HAL_GetTick());
//		n += sprintf(logdata + n, "%x ", (int) RxHeader.StdId);
//		for (int i = 0; i < RxHeader.DLC; i++) {
//			n += sprintf(logdata + n, "%02x ", data[i]);
//		}
//		n += sprintf(logdata + n, "\n");
//		printf(logdata);
//	} else if (RxHeader.IDE == CAN_ID_EXT) // Extended CAN DATA SAVE
//	{
//		// append all data to logdata
//		n += sprintf(logdata + n, "%13d ", (int) HAL_GetTick());
//		n += sprintf(logdata + n, "%x ", (int) RxHeader.StdId);
//		for (int i = 0; i < RxHeader.DLC; i++) {
//			n += sprintf(logdata + n, "%02x ", data[i]);
//		}
//		n += sprintf(logdata + n, "\n");
//	}
//	n = 0;
//	printf(logdata);
//}

char LOGFILENAME[25] = "datafile1.txt";
void SD_Card_Init() {

	//SD card initialization
	if (sd_mount("") != FR_OK) {
		ActionMsg("SD card mount", "failed");
		return;
	}
	ActionMsg("SD card mount", "succeed");

	if (sd_open(LOGFILENAME, FA_CREATE_NEW) != FR_OK) {
		ActionMsg("File create", "failed");
		if (sd_open(LOGFILENAME, FA_WRITE) != FR_OK) {
			ActionMsg("File Reset Write Open", "failed");
			return;
		}
		ActionMsg("File Reset Write Open", "succeed");

		if (sd_append("\n") != FR_OK) {
			ActionMsg("File Reset Write", "failed");
			return;
		}
		ActionMsg("File Reset Write", "succeed");

		if (sd_close() != FR_OK) {
			ActionMsg("File Reset close", "failed");
			return;
		}
		ActionMsg("File Reset close", "succeed");

	}
	ActionMsg("File create", "succeed");

	if (sd_close() != FR_OK) {
		ActionMsg("File close", "failed");
		return;
	}
	ActionMsg("File close", "succeed");
}

void Loopfunction() {
	char logdata[100];
	int n = 0;
	n += sprintf(logdata + n, "Hello World\n");

	if (sd_open(LOGFILENAME, FA_WRITE) != FR_OK) {
		ActionMsg("File open in write", "failed");
		printf("failed");
		return;
	}
	ActionMsg("File open in write", "succeed");

	if (sd_append(logdata) != FR_OK) {
		ActionMsg("File append", "failed");
		return;
	}
	ActionMsg("File append", "succeed");

	if (sd_close() != FR_OK) {
		ActionMsg("File close", "failed");
		return;
	}

	HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);

}




