/*
 * I2C_DS3231.c
 *
 *  Created on: Oct 19, 2022
 *      Author: admin
 */

#include "main.h"
#include "I2C_DS3231.h"
#include "stdio.h"

extern I2C_HandleTypeDef hi2c1;

// convert normal decimal number to binary coded decimal
uint8_t decToBcd (int val){
	return (uint8_t)((val/10*16)+(val%10));
}

// convert binary to coded decimal to normal decimal number
int bcdTDec(uint8_t val){
	return (int)((val/16*10)+(val%16));
}


void Set_Time(uint8_t sec, uint8_t min,uint8_t hour, uint8_t dow, uint8_t dom, uint8_t month, uint8_t year)
{
	printf("Saving Time\n");
	uint8_t set_time[7];
	set_time[0]=decToBcd(sec);
	set_time[1]=decToBcd(min);
	set_time[2]=decToBcd(hour);
	set_time[3]=decToBcd(dow);
	set_time[4]=decToBcd(dom);
	set_time[5]=decToBcd(month);
	set_time[6]=decToBcd(year);

	HAL_I2C_Mem_Write(&hi2c1, DS3231_ADDRESS, 0x00, 1, set_time, 7, 1000);
//	printf("Time set to: 20%d:%d:%d: :%d: :%d:%d:%d\n",year,month,dom, dow,hour,min,sec);
}

TIME Get_Time(void){
	TIME time;
	uint8_t get_time[7];
	HAL_I2C_Mem_Read(&hi2c1, DS3231_ADDRESS, 0x00, 1, get_time, 7, 1000);
	time.seconds =bcdTDec(get_time[0]);
	time.minutes=bcdTDec(get_time[1]);
	time.hours=bcdTDec(get_time[2]);
	time.dayoftheweek=bcdTDec(get_time[3]);
	time.dayofthemonth=bcdTDec(get_time[4]);
	time.month=bcdTDec(get_time[5]);
	time.year=bcdTDec(get_time[6]);
	return time;
}

float Get_temp(void){
	uint8_t temp[2];
	HAL_I2C_Mem_Read(&hi2c1, DS3231_ADDRESS, 0x11, 1, temp, 2, 1000);
	return ((temp[0])+(temp[1]>>6)/4.0);
}

void force_temp_conv (void){
	uint8_t status =0;
	uint8_t control = 0;
	HAL_I2C_Mem_Read(&hi2c1, DS3231_ADDRESS, 0X0F, 1, &status, 1, 100); // read the status resistor
	if(!(status&0x04))
	{
		HAL_I2C_Mem_Read(&hi2c1, DS3231_ADDRESS, 0X0E, 1, &control, 1,100); // read control resistor
		HAL_I2C_Mem_Write(&hi2c1, DS3231_ADDRESS, 0x0E, 1, (uint8_t *)(control|(0x02)), 1, 100);
	}
}
