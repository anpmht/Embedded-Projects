/*
 * I2C_DS3231.h
 *
 *  Created on: Sep 10, 2022
 *      Author: yazur
 */

#ifndef INC_I2C_DS3231_H_
#define INC_I2C_DS3231_H_


#include "main.h"

#define DS3231_ADDRESS 0xD0

typedef struct{
	uint8_t seconds;
	uint8_t minutes;
	uint8_t hours;
	uint8_t dayoftheweek;
	uint8_t dayofthemonth;
	uint8_t month;
	uint8_t year;

} TIME;


uint8_t decToBcd (int val);
int bcdTDec(uint8_t val);



void Set_Time(uint8_t sec, uint8_t min,uint8_t hour, uint8_t dow, uint8_t dom, uint8_t month, uint8_t year);
TIME Get_Time(void);

float Get_temp(void);
void force_temp_conv (void);

#endif /* INC_I2C_DS3231_H_ */
