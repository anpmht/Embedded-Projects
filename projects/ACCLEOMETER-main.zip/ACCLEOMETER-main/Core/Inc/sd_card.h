/*
 * sd_card.h
 *
 *  Created on: Nov 29, 2022
 *      Author: admin
 */

#ifndef INC_SD_CARD_H_
#define INC_SD_CARD_H_

#include "fatfs.h"
#define MAX_LINE_SIZE 1024 //in kB

FRESULT sd_mount(const char*);
FRESULT sd_open(const char*, BYTE);
FRESULT sd_unmount(const char*);
FRESULT sd_write(const char*);
FRESULT sd_read(char*);
FRESULT sd_gets(const char*);
FRESULT sd_close(void);
FRESULT sd_lseek(void);
FRESULT sd_append(const char*);
FRESULT sd_readln(char *);
FRESULT sd_eof(void);
FRESULT sd_delete(const char*);
int sd_fileSize();

#endif /* INC_SD_CARD_H_ */
