/*
 * basic_function.h
 *
 *  Created on: Nov 29, 2022
 *      Author: admin
 */

#ifndef INC_BASIC_FUNCTION_H_
#define INC_BASIC_FUNCTION_H_

#include "main.h"



void toogle(GPIO_TypeDef* gpio_set, uint16_t gpio_pin);
void ActionMsg(const char *title, const char *error_msg);
//void CAN_Initilization();
//void CAN_Transmit(uint32_t ID, char *data);
//void CAN_Receive_Interupt();
void SD_Card_Init();
void Loopfunction();
#endif /* INC_BASIC_FUNCTION_H_ */
