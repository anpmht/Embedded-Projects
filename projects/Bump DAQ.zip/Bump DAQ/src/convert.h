double convertToStrain(double voltage, double excitation, double gain, double gaugeFactor);
double convertToWeight(double voltage, double excitation, double gain);