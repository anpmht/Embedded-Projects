#include "Arduino.h"

long strain(int mv, int gain) {
    long strain = 0.00;
    return strain;
}