double convertToStrain(double voltage, double excitation, double gain, double gaugeFactor)
{
    double strain = (voltage*206.0) / (excitation * gain * gaugeFactor);
    return strain;
}

double convertToWeight(double voltage, double excitation, double gain){
    double load = (voltage/(gain*excitation))*1000.0;
    return load;
}