// void logData();
// void clearSerialInput();
// void logData();