#include "adxl345Setup.h"
#include <Arduino.h>
// #include <adxl345Setup.h>

#include <SPI.h>

// digitalWrite(SS, HIGH); // ensure SS stays high

ADXL345 adxl1 = ADXL345(0);
ADXL345 adxl2 = ADXL345(1);
ADXL345 adxl3 = ADXL345(2);

SPISettings ADXL345SPISettings(SPISpeedADXL345, MSBFIRST, SPI_MODE3);

void setupADXL345() {
  SPI.beginTransaction(ADXL345SPISettings);

  Serial.println("SparkFun ADXL345 Accelerometer Hook Up Guide Example");
  Serial.println();

  adxl1.powerOn();
  // delay(100);
  adxl1.setRangeSetting(2);
  // delay(100);
  adxl1.setSpiBit(0);
  // delay(100);
  adxl1.set_bw(ADXL345_BW_1600);
  // delay(100);

  adxl2.powerOn();
  // delay(100);
  adxl2.setRangeSetting(2);
  // delay(100);
  adxl2.setSpiBit(0);
  // delay(100);
  adxl2.set_bw(ADXL345_BW_1600);
  // delay(100);

  adxl3.powerOn();
  // delay(100);
  adxl3.setRangeSetting(2);
  // delay(100);
  adxl3.setSpiBit(0);
  // delay(100);
  adxl3.set_bw(ADXL345_BW_1600);
  delay(100);
  SPI.endTransaction();
}

void getDataFromADXL345() {
  SPI.beginTransaction(ADXL345SPISettings);

  // adxl = ADXL345(9);
  int x1, y1, z1;
  int x2, y2, z2;
  int x3, y3, z3;
  adxl1.readAccel(&x1, &y1, &z1);
  adxl2.readAccel(&x2, &y2, &z2);
  adxl3.readAccel(&x3, &y3, &z3);

  Serial.print(x1);
  Serial.print(",\t");
  Serial.print(y1);
  Serial.print(",\t");
  Serial.print(z1);
  Serial.print("\t\t");

  Serial.print(x2);
  Serial.print(",\t");
  Serial.print(y2);
  Serial.print(",\t");
  Serial.print(z2);
  Serial.print("\t\t");

  Serial.print(x3);
  Serial.print(",\t");
  Serial.print(y3);
  Serial.print(",\t");
  Serial.print(z3);
  Serial.print("\t\t");
  Serial.println("");
  // delay(100);
  SPI.endTransaction();
}
