#include <Arduino.h>  // search first in same compiler/IDE directory.
#include <SPI.h>
#include <TimeLib.h>
#include <Wire.h>

#include "Teensy_time.h"
#include "ada4254.h"
#include "ads1256Setup.h"  // search first in same directory
#include "encoder.h"
#include "logdata.h"

ADA4254 ada(&SPI, 0, 1);

int ampCS[16] = {8, 9, 10, 14, 15, 16, 24, 25, 26, 27, 28, 37, 38, 39, 40, 41};
int adcDrdy[4] = {29, 31, 34, 36};
int acdCS[4] = {30, 32, 33, 35};

void setupIO(){
    for(int i = 0; i<16; i++){
        pinMode(ampCS[i], OUTPUT);
    }
    for(int i = 0; i<16; i++){
        digitalWrite(ampCS[i], HIGH);
    }
    for(int i = 0; i<4; i++){
        pinMode(acdCS[i], OUTPUT);
    }
    for(int i = 0; i<4; i++){
        digitalWrite(acdCS[i], HIGH);
    }
    for(int i = 0; i<4; i++){
        pinMode(adcDrdy[i], INPUT);
    }
}

void setupADA4254() {
    // 16 amplifier's gain setting
    delay(100);
    SPI.begin();
    SPI.beginTransaction(SPISettings(50000, MSBFIRST, SPI_MODE0));
    for (int i = 0; i < 16; i++) {
        // ada.available(cs[i]);
        Serial.println(ampCS[i]);
        ada.init(ampCS[i]);
        ada.calibration(ampCS[i]);
        ada.connectInputP20mv(ampCS[i]);
        ada.writeRegister(0x0A, 223, ampCS[i]);
        ada.writeRegister(0x0A, 191, ampCS[i]);
        ada.writeRegister(0x07, 2, ampCS[i]);
        // ada.writeRegister(0x00, 88, ampCS[i]);
        // ada.readRegister(0x00, ampCS[i]);
        // ada.writeRegister(0x03, 2);
        ada.setGain(GAIN1, ampCS[i]);
        // for (int j = 0; j < 11; j++) {
        //     ada.readRegister(j, 10);
        // }
    }
    SPI.endTransaction();
    for (int i = 0; i < 16; i++) {
        digitalWrite(ampCS[i], HIGH);
    }
}

void setup() {
    setupIO();
    Serial.begin(115200);
    setupADA4254();
    delay(1000);
    setupADS1256();
    // ADXL345setup();
    // time_setup();
}

void loop() {
    // while (!digitalRead(9)) {
    // };
    // logData();
}
