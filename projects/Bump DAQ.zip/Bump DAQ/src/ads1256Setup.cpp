#include "ads1256Setup.h"

#include <Arduino.h>

#include "LiquidCrystal_I2C.h"
#include "RingBuf.h"
#include "SdFat.h"
#include "Teensy_time.h"
#include "ads1256.h"
#include "adxl345Setup.h"
#include "convert.h"

// Use Teensy SDIO
#define SD_CONFIG SdioConfig(FIFO_SDIO)
// Interval between points for 25 ksps.
#define LOG_INTERVAL_USEC 40
// Size to log 10 byte lines at 25 kHz for more than ten minutes.
#define LOG_FILE_SIZE 10 * 25000 * 600  // 150,000,000 bytes.
// Space to hold more than 800 ms of data for 10 byte lines at 25 ksps.
#define RING_BUF_CAPACITY 400 * 512
// #define LOG_FILENAME   "DAQ_LOG_11.csv"
int noOfFiles = 0;
int maxNoOfFiles = 2;
uint32_t previousMicros = micros();
// Max RingBuf used bytes. Useful to understand RingBuf overrun.
size_t maxUsed = 0;
// Min spare micros in loop.
int32_t minSpareMicros = INT32_MAX;
uint32_t lastWriteMicros = 0;
uint32_t logTime = micros();
SdFs sd;
FsFile file;
// RingBuf for File type FsFile.
RingBuf<FsFile, RING_BUF_CAPACITY> rb;

ADS1256 firstADS1256;
ADS1256 secondADS1256;
ADS1256 thirdADS1256;
ADS1256 forthADS1256;

double readingVoltage;
const int noOfBoards = 4;
const int noOfChannels = 8;
double readingValueArray[noOfBoards][noOfChannels];
int boardNo = 0;
int channelNo = 0;
double excitation = 9.00;
double gain = 128.00;
double gaugeFactor = 2.00;

struct {
    int value[8] = {1, 2, 3, 4, 5, 6, 7, 8};
    String location[8] = {
        "x:", "ML:", "MR:", "SWL:", "SWR:", "LY:", "LZ:", "LX:"};
    int amp_no[16] = {18, 15, 16, 17, 14, 11, 12, 13,
                     28, 25, 26, 27, 24, 21, 22, 23};
} myLabel;

void setupADS1256() {
    delay(10);
    firstADS1256.begin(35, 36, 4, PGA_1, DR_30000);
    firstADS1256.resetADS1256();
    firstADS1256.userDefaultRegisters();

    delay(10);
    secondADS1256.begin(33, 34, 4, PGA_1, DR_30000);
    secondADS1256.resetADS1256();
    secondADS1256.userDefaultRegisters();

    delay(10);
    thirdADS1256.begin(30, 29, 4, PGA_1, DR_30000);
    thirdADS1256.resetADS1256();
    thirdADS1256.userDefaultRegisters();

    delay(10);
    forthADS1256.begin(32, 31, 4, PGA_1, DR_30000);
    forthADS1256.resetADS1256();
    forthADS1256.userDefaultRegisters();
    Serial.println("<setupADS1256 finished>");
}

void ADXL345setup() { setupADXL345(); }

void logData() {
    // Initialize the SD.
    // setupLogging();
    // Open or create file - truncate existing file.
    // creatNewFile();
    // read and log sensor data
    readSensor();
    // Write any RingBuf data tos file.
    // endLogging();
    // Print first twenty lines of file.
    // printData();
    // print info on logged file
    // printFileInfo();
}

void endLogging() {
    rb.sync();
    file.sync();
    file.truncate();
    file.rewind();
}

void printData() {
    for (uint8_t n = 0; n < 20 && file.available();) {
        int c = file.read();
        if (c < 0) {
            // Serial.print("EOL. Ser"); // won't get printed because of
            // file.available()
            break;
        }
        Serial.write(c);
        if (c == '\n') n++;
    }
    file.close();
}

void printFileInfo() {
    Serial.print("fileSize: ");
    Serial.println((uint32_t)file.fileSize());
    Serial.print("maxBytesUsed: ");
    Serial.println(maxUsed);
    Serial.print("minSpareMicros: ");
    Serial.println(minSpareMicros);
}

void setupLogging() {
    // Initialize the SD.
    if (!sd.begin(SD_CONFIG)) {
        sd.initErrorHalt(&Serial);
    }
}

void creatNewFile() {
    char *fileName = fileNameFromRTC();

    if (!file.open(fileName, O_RDWR | O_CREAT | O_TRUNC)) {
        Serial.println("open failed\n");
        return;
    }
    // File must be pre-allocated to avoid huge
    // delays searching for free clusters.
    // uint32_t t1 = micros();
    if (!file.preAllocate(LOG_FILE_SIZE)) {
        Serial.println("preAllocate failed\n");
        file.close();
        return;
    }
    // uint32_t t2 = micros();
    // initialize the RingBuf.
    rb.begin(&file);

    Serial.println("turn off to stop");
    // Start time.
    logTime = micros();
    // Log data until Serial input or file full.
    // rb.write("b1amp8,b1amp5,b1amp6,b1amp7,b1amp4,b1amp1,b1amp2,b1amp3,b2amp8,b2amp5,b2amp6,b2amp7,b2amp4,b2amp1,b2amp2,b2amp3,t");
    // rb.println();
    // rb.sync();
    logTime = micros();
}

void readSensor() {
    // Serial.println("turn the log switch on to start logging");
    int log = 1;
    while (log == 1) {
        // size_t n = rb.bytesUsed();
        // if ((n + file.curPosition()) > (LOG_FILE_SIZE - 20)) {
        //     Serial.println("File full - quitting.");
        //     break;
        // }
        // if (n > maxUsed) {
        //     maxUsed = n;
        // }
        // if (n >= 512 && !file.isBusy()) {
        //     // Not busy only allows one sector before possible busy wait.
        //     // Write one sector from RingBuf to file.
        //     if (512 != rb.writeOut(512)) {
        //         Serial.println("writeOut failed");
        //         break;
        //     }
        // }
        // // Time for next point.
        // logTime += LOG_INTERVAL_USEC;
        // int32_t spareMicros = logTime - micros();
        // if (spareMicros < minSpareMicros) {
        //     minSpareMicros = spareMicros;
        // }
        // if (spareMicros <= 0) {
        //     // Serial.print("Rate too fast ");
        //     // Serial.println(spareMicros);
        //     // break;
        // }

        for (boardNo = 0; boardNo < 4; boardNo++) {
            for (int channelNo = 0; channelNo < 4; channelNo++) {
                switch (boardNo) {
                    case 0:
                        readingVoltage =
                            firstADS1256.readChannelContinuousMode(channelNo);
                        break;
                    case 1:
                        readingVoltage =
                            secondADS1256.readChannelContinuousMode(channelNo);
                        break;
                    case 2:
                        readingVoltage =
                            thirdADS1256.readChannelContinuousMode(channelNo);
                        break;
                    case 3:
                        readingVoltage =
                            forthADS1256.readChannelContinuousMode(channelNo);
                        break;
                }
                // double strain = convertToStrain(readingVoltage, excitation,
                // gain, gaugeFactor);
                readingValueArray[boardNo][channelNo] = readingVoltage;
                // digitalWrite(30, HIGH);
            }
        }

        // rb.print(getRTCData());
        // rb.print(",");
        // for (int b = 0; b < 4; b++) {
        //     for (int p = 0; p < 4; p++) {
        //         rb.print(readingValueArray[b][p], 4);
        //         rb.write(',');
        //     }
        // }
        // rb.println(micros());
        // Serial.print(getRTCData());
        // Serial.print('\t');
        for (int b = 0; b < 4; b++) {
            for (int p = 0; p < 4; p++) {
                Serial.print(readingValueArray[b][p], 2);
                Serial.print(',');
            }
        }
        // getDataFromADXL345();
        Serial.println(millis());
        // Serial.print("time:");
        // Serial.println(1);
        // if (rb.getWriteError()) {
        //     // Error caused by too few free bytes in RingBuf.
        //     Serial.println("WriteError");
        //     break;
        // }
    }
}