#ifndef ADS1256SETUP_H
#define ADS1256SETUP_H

# include "ads1256.h"

void setupADS1256();
// void getDataFromADS1256();
void logData();
void endLogging();
void printData();
void printFileInfo();
void setupLogging();
void creatNewFile();
void readSensor();
void init_lcd1();
void ADXL345setup();
#endif