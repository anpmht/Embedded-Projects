#include <Arduino.h>
void time_setup();
String read_time();
void digitalClockDisplay();
time_t getTeensy3Time();
unsigned long processSyncMessage();
void printDigits(int digits);
char* fileNameFromRTC();
char* getRTCData();