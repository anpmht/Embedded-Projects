#ifndef ADXL345_H
#define ADXL345_H
#include "SparkFun_ADXL345.h"

#define SPISpeedADXL345 4000000

void setupADXL345();
void getDataFromADXL345();
#endif